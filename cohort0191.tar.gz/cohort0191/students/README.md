# How to work with this web 🤔

- Create in this folder your own folder witch will contain your HTML and your CSS.
- Please name the folder with your name : francesca 📁 --> index.html & styles.css.

**DO NOT touch the main index.html, thanksss 😬**